namespace SleepyMonti
{
    partial class AddClientForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle       = new System.Windows.Forms.Label();
            this.lblName        = new System.Windows.Forms.Label();
            this.txtName        = new System.Windows.Forms.TextBox();
            this.lblPhone       = new System.Windows.Forms.Label();
            this.txtPhone       = new System.Windows.Forms.TextBox();
            this.lblAddress     = new System.Windows.Forms.Label();
            this.txtAddress     = new System.Windows.Forms.TextBox();
            this.btnSave        = new System.Windows.Forms.Button();
            this.btnCancel      = new System.Windows.Forms.Button();
            this.panelTop       = new System.Windows.Forms.Panel();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();

            // panelTop
            this.panelTop.BackColor   = System.Drawing.Color.FromArgb(88, 60, 100);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Dock        = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location    = new System.Drawing.Point(0, 0);
            this.panelTop.Name        = "panelTop";
            this.panelTop.Size        = new System.Drawing.Size(420, 48);
            this.panelTop.TabIndex    = 0;

            // lblTitle
            this.lblTitle.AutoSize  = false;
            this.lblTitle.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Font      = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Text      = "➕  Добавление нового клиента";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Name      = "lblTitle";

            // lblName
            this.lblName.AutoSize  = true;
            this.lblName.Location  = new System.Drawing.Point(20, 68);
            this.lblName.Name      = "lblName";
            this.lblName.Text      = "ФИО клиента:";
            this.lblName.Font      = new System.Drawing.Font("Segoe UI", 9.5F);

            // txtName
            this.txtName.Location  = new System.Drawing.Point(160, 65);
            this.txtName.Name      = "txtName";
            this.txtName.Size      = new System.Drawing.Size(240, 26);
            this.txtName.Font      = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtName.TabIndex  = 1;

            // lblPhone
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(20, 108);
            this.lblPhone.Name     = "lblPhone";
            this.lblPhone.Text     = "Телефон:";
            this.lblPhone.Font     = new System.Drawing.Font("Segoe UI", 9.5F);

            // txtPhone
            this.txtPhone.Location = new System.Drawing.Point(160, 105);
            this.txtPhone.Name     = "txtPhone";
            this.txtPhone.Size     = new System.Drawing.Size(240, 26);
            this.txtPhone.Font     = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtPhone.TabIndex = 2;

            // lblAddress
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(20, 148);
            this.lblAddress.Name     = "lblAddress";
            this.lblAddress.Text     = "Адрес доставки:";
            this.lblAddress.Font     = new System.Drawing.Font("Segoe UI", 9.5F);

            // txtAddress
            this.txtAddress.Location = new System.Drawing.Point(160, 145);
            this.txtAddress.Name     = "txtAddress";
            this.txtAddress.Size     = new System.Drawing.Size(240, 26);
            this.txtAddress.Font     = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtAddress.TabIndex = 3;

            // btnSave
            this.btnSave.BackColor    = System.Drawing.Color.FromArgb(46, 160, 67);
            this.btnSave.FlatStyle    = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.ForeColor    = System.Drawing.Color.White;
            this.btnSave.Font         = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnSave.Location     = new System.Drawing.Point(220, 195);
            this.btnSave.Name         = "btnSave";
            this.btnSave.Size         = new System.Drawing.Size(100, 32);
            this.btnSave.TabIndex     = 4;
            this.btnSave.Text         = "Сохранить";
            this.btnSave.Click       += new System.EventHandler(this.btnSave_Click);

            // btnCancel
            this.btnCancel.BackColor  = System.Drawing.Color.FromArgb(180, 180, 180);
            this.btnCancel.FlatStyle  = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor  = System.Drawing.Color.White;
            this.btnCancel.Font       = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnCancel.Location   = new System.Drawing.Point(110, 195);
            this.btnCancel.Name       = "btnCancel";
            this.btnCancel.Size       = new System.Drawing.Size(100, 32);
            this.btnCancel.TabIndex   = 5;
            this.btnCancel.Text       = "Отмена";
            this.btnCancel.Click     += new System.EventHandler(this.btnCancel_Click);

            // AddClientForm
            this.AcceptButton        = this.btnSave;
            this.CancelButton        = this.btnCancel;
            this.BackColor           = System.Drawing.Color.FromArgb(252, 248, 255);
            this.ClientSize          = new System.Drawing.Size(420, 248);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Font                = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle     = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox         = false;
            this.MinimizeBox         = false;
            this.Name                = "AddClientForm";
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text                = "Добавление клиента";
            this.panelTop.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label      lblTitle;
        private System.Windows.Forms.Label      lblName;
        private System.Windows.Forms.TextBox    txtName;
        private System.Windows.Forms.Label      lblPhone;
        private System.Windows.Forms.TextBox    txtPhone;
        private System.Windows.Forms.Label      lblAddress;
        private System.Windows.Forms.TextBox    txtAddress;
        private System.Windows.Forms.Button     btnSave;
        private System.Windows.Forms.Button     btnCancel;
        private System.Windows.Forms.Panel      panelTop;
    }
}
