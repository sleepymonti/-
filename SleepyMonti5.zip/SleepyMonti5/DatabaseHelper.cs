using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ClosedXML.Excel;

namespace SleepyMonti
{
    public static class DatabaseHelper
    {
        public static readonly string DataFile =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SleepyMonti_Data.xlsx");

        private static readonly Random Rng = new Random();

        // ── Safe cell readers ─────────────────────────────────

        private static string S(IXLCell c)
        {
            try { return c == null || c.IsEmpty() ? "" : c.GetString(); }
            catch { return ""; }
        }

        private static int I(IXLCell c)
        {
            try
            {
                if (c == null || c.IsEmpty()) return 0;
                var v = c.Value;
                if (v.IsNumber) return (int)v.GetNumber();
                return int.TryParse(c.GetString(), out int r) ? r : 0;
            }
            catch { return 0; }
        }

        private static decimal D(IXLCell c)
        {
            try
            {
                if (c == null || c.IsEmpty()) return 0m;
                var v = c.Value;
                if (v.IsNumber) return (decimal)v.GetNumber();
                return decimal.TryParse(
                    c.GetString().Replace(",", "."),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out decimal r) ? r : 0m;
            }
            catch { return 0m; }
        }

        private static bool B(IXLCell c)
        {
            try
            {
                if (c == null || c.IsEmpty()) return true;
                var v = c.Value;
                if (v.IsBoolean) return v.GetBoolean();
                if (v.IsNumber)  return v.GetNumber() != 0;
                string s = c.GetString().ToLower().Trim();
                return s == "true" || s == "1" || s == "да" || s == "yes";
            }
            catch { return true; }
        }

        // ── Helpers ────────────────────────────────────────────

        private static XLWorkbook Open() => new XLWorkbook(DataFile);

        private static int LastRow(IXLWorksheet ws)
        {
            var r = ws.LastRowUsed();
            return r == null ? 1 : r.RowNumber();
        }

        private static int NextId(IXLWorksheet ws)
        {
            int lr = LastRow(ws);
            return lr <= 1 ? 1 : I(ws.Cell(lr, 1)) + 1;
        }

        private static int FindRow(IXLWorksheet ws, int id)
        {
            int lr = LastRow(ws);
            for (int r = 2; r <= lr; r++)
                if (!ws.Cell(r, 1).IsEmpty() && I(ws.Cell(r, 1)) == id)
                    return r;
            return -1;
        }

        private static void Write(IXLWorksheet ws, int row, params object[] vals)
        {
            for (int i = 0; i < vals.Length; i++)
            {
                var cell = ws.Cell(row, i + 1);
                if      (vals[i] == null)          cell.Value = "";
                else if (vals[i] is bool   bv)     cell.Value = bv;
                else if (vals[i] is int    iv)     cell.Value = (double)iv;
                else if (vals[i] is long   lv)     cell.Value = (double)lv;
                else if (vals[i] is double dv)     cell.Value = dv;
                else if (vals[i] is decimal dec)   cell.Value = (double)dec;
                else if (vals[i] is float  fv)     cell.Value = (double)fv;
                else                               cell.Value = vals[i].ToString();
            }
        }

        private static IXLWorksheet AddSheet(XLWorkbook wb, string name, string[] headers)
        {
            var ws = wb.AddWorksheet(name);
            for (int i = 0; i < headers.Length; i++)
                ws.Cell(1, i + 1).Value = headers[i];
            var rng = ws.Range(1, 1, 1, headers.Length);
            rng.Style.Font.Bold = true;
            rng.Style.Font.FontColor = XLColor.White;
            rng.Style.Fill.BackgroundColor = XLColor.FromArgb(88, 60, 100);
            rng.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            return ws;
        }

        // ── Init ───────────────────────────────────────────────

        public static void InitializeDatabase()
        {
            if (File.Exists(DataFile)) return;

            using (var wb = new XLWorkbook())
            {
                AddSheet(wb, "Clients",  new[] { "Id","Name","Phone","Address" });

                var wsP = AddSheet(wb, "Products",
                    new[] { "Id","Name","Category","Price","Description","IsAvailable" });

                var wsK = AddSheet(wb, "Couriers",
                    new[] { "Id","Name","Phone","ActiveOrders" });

                AddSheet(wb, "Orders",
                    new[] { "Id","ClientId","CourierId","DeliveryAddress","OrderDate","Status","Total","DeliveryMinutes" });

                AddSheet(wb, "OrderItems",
                    new[] { "Id","OrderId","ProductId","Quantity","Price" });

                AddSheet(wb, "MonthlyStats",
                    new[] { "Id","CourierId","Year","Month","Count" });

                SeedProducts(wsP);
                SeedCouriers(wsK);
                wb.SaveAs(DataFile);
            }
        }

        private static void SeedProducts(IXLWorksheet ws)
        {
            int r = 2;
            Write(ws, r++, 1,  "Торт Наполеон",       "Торты",    45.00, "Классический торт из слоёного теста с заварным кремом", true);
            Write(ws, r++, 2,  "Торт Медовик",         "Торты",    40.00, "Медовый торт с нежным сметанным кремом",                true);
            Write(ws, r++, 3,  "Торт Захер",           "Торты",    55.00, "Австрийский шоколадный торт с абрикосовым джемом",      true);
            Write(ws, r++, 4,  "Торт Красный бархат",  "Торты",    50.00, "Яркий торт со сливочным кремом-чиз",                   true);
            Write(ws, r++, 5,  "Чизкейк Нью-Йорк",    "Чизкейки", 38.00, "Классический нью-йоркский чизкейк без выпечки",         true);
            Write(ws, r++, 6,  "Чизкейк с черникой",   "Чизкейки", 42.00, "Нежный чизкейк с ягодным топпингом",                   true);
            Write(ws, r++, 7,  "Макаруны набор 6 шт",  "Пирожные", 18.00, "Французские миндальные пирожные ассорти",               true);
            Write(ws, r++, 8,  "Эклеры набор 4 шт",    "Пирожные", 15.00, "Заварные пирожные с шоколадной глазурью",               true);
            Write(ws, r++, 9,  "Шоколадный брауни",    "Пирожные",  8.00, "Насыщенный шоколадный брауни с грецким орехом",         true);
            Write(ws, r++, 10, "Тирамису порция",       "Десерты",  12.00, "Итальянский десерт с маскарпоне и кофе",                true);
            Write(ws, r++, 11, "Панна-котта",           "Десерты",  10.00, "Нежный сливочный десерт с ягодным соусом",              true);
            Write(ws, r++, 12, "Круассан с маслом",     "Выпечка",   4.50, "Слоёный круассан из дрожжевого теста",                  true);
            Write(ws, r++, 13, "Кекс с черникой",       "Выпечка",   6.00, "Нежный кекс со свежей черникой",                       true);
            Write(ws, r,   14, "Синнабон",               "Выпечка",   7.00, "Булочка с корицей и сливочной глазурью",                true);
        }

        private static void SeedCouriers(IXLWorksheet ws)
        {
            Write(ws, 2, 1, "Иванов Алексей Петрович",  "+375291234567", 0);
            Write(ws, 3, 2, "Петров Дмитрий Сергеевич", "+375297654321", 0);
            Write(ws, 4, 3, "Сидорова Анна Игоревна",   "+375291112233", 0);
        }

        // ── Clients ────────────────────────────────────────────

        public static List<Client> GetClients(string search = "")
        {
            var list = new List<Client>();
            using (var wb = Open())
            {
                var ws = wb.Worksheet("Clients");
                int lr = LastRow(ws);
                for (int r = 2; r <= lr; r++)
                {
                    if (ws.Cell(r, 1).IsEmpty()) continue;
                    var c = new Client { Id=I(ws.Cell(r,1)), Name=S(ws.Cell(r,2)),
                                         Phone=S(ws.Cell(r,3)), Address=S(ws.Cell(r,4)) };
                    if (string.IsNullOrWhiteSpace(search) ||
                        c.Phone.Contains(search) ||
                        c.Name.ToLower().Contains(search.ToLower()))
                        list.Add(c);
                }
            }
            return list.OrderBy(c => c.Name).ToList();
        }

        public static Client SearchClientByPhone(string phone) =>
            GetClients().FirstOrDefault(c =>
                c.Phone.Equals(phone?.Trim() ?? "", StringComparison.OrdinalIgnoreCase));

        public static int AddClient(Client cl)
        {
            using (var wb = Open())
            {
                var ws = wb.Worksheet("Clients");
                int id = NextId(ws), row = LastRow(ws) + 1;
                Write(ws, row, id, cl.Name, cl.Phone, cl.Address ?? "");
                wb.Save(); return id;
            }
        }

        // ── Products ───────────────────────────────────────────

        public static List<Product> GetProducts(string category = "", decimal maxPrice = 0, string search = "")
        {
            var list = new List<Product>();
            using (var wb = Open())
            {
                var ws = wb.Worksheet("Products");
                int lr = LastRow(ws);
                for (int r = 2; r <= lr; r++)
                {
                    if (ws.Cell(r, 1).IsEmpty()) continue;
                    var p = new Product
                    {
                        Id=I(ws.Cell(r,1)), Name=S(ws.Cell(r,2)), Category=S(ws.Cell(r,3)),
                        Price=D(ws.Cell(r,4)), Description=S(ws.Cell(r,5)), IsAvailable=B(ws.Cell(r,6))
                    };
                    bool ok = (string.IsNullOrWhiteSpace(category) || category == "Все категории" || p.Category == category)
                           && (maxPrice <= 0 || p.Price <= maxPrice)
                           && (string.IsNullOrWhiteSpace(search) || p.Name.ToLower().Contains(search.ToLower()));
                    if (ok) list.Add(p);
                }
            }
            return list.OrderBy(p => p.Category).ThenBy(p => p.Name).ToList();
        }

        public static List<string> GetCategories()
        {
            var cats = new List<string> { "Все категории" };
            cats.AddRange(GetProducts().Select(p => p.Category)
                .Where(c => !string.IsNullOrWhiteSpace(c)).Distinct().OrderBy(c => c));
            return cats;
        }

        public static void AddProduct(Product p)
        {
            using (var wb = Open())
            {
                var ws = wb.Worksheet("Products");
                int id = NextId(ws), row = LastRow(ws) + 1;
                Write(ws, row, id, p.Name, p.Category, (double)p.Price, p.Description ?? "", p.IsAvailable);
                wb.Save();
            }
        }

        public static void DeleteProduct(int id)
        {
            using (var wb = Open())
            {
                var ws = wb.Worksheet("Products");
                int row = FindRow(ws, id);
                if (row > 1) { ws.Row(row).Delete(); wb.Save(); }
            }
        }

        public static void UpdateProductAvailability(int id, bool avail)
        {
            using (var wb = Open())
            {
                var ws = wb.Worksheet("Products");
                int row = FindRow(ws, id);
                if (row > 1) { ws.Cell(row, 6).Value = avail; wb.Save(); }
            }
        }

        // ── Couriers ───────────────────────────────────────────

        public static List<Courier> GetCouriers()
        {
            var list = new List<Courier>();
            using (var wb = Open())
            {
                var ws = wb.Worksheet("Couriers");
                int lr = LastRow(ws);
                for (int r = 2; r <= lr; r++)
                {
                    if (ws.Cell(r, 1).IsEmpty()) continue;
                    list.Add(new Courier
                    {
                        Id=I(ws.Cell(r,1)), Name=S(ws.Cell(r,2)),
                        Phone=S(ws.Cell(r,3)), ActiveOrders=I(ws.Cell(r,4))
                    });
                }
            }
            return list;
        }

        /// <summary>Назначает случайного курьера.</summary>
        public static Courier AssignRandomCourier()
        {
            var couriers = GetCouriers();
            if (couriers.Count == 0) return null;
            return couriers[Rng.Next(couriers.Count)];
        }

        private static void ChangeCourierOrders(XLWorkbook wb, int courierId, int delta)
        {
            var ws  = wb.Worksheet("Couriers");
            int row = FindRow(ws, courierId);
            if (row > 1)
            {
                int cur = I(ws.Cell(row, 4));
                ws.Cell(row, 4).Value = (double)Math.Max(0, cur + delta);
            }
        }

        // ── Orders ─────────────────────────────────────────────

        public static int SaveOrder(Order order)
        {
            using (var wb = Open())
            {
                var wsO = wb.Worksheet("Orders");
                var wsI = wb.Worksheet("OrderItems");
                int oid  = NextId(wsO);
                int orow = LastRow(wsO) + 1;
                Write(wsO, orow,
                    oid, order.ClientId, order.CourierId,
                    order.DeliveryAddress,
                    DateTime.Now.ToString("dd.MM.yyyy HH:mm"),
                    "В обработке",
                    (double)order.Total,
                    order.DeliveryMinutes);

                int iid  = NextId(wsI);
                int irow = LastRow(wsI) + 1;
                foreach (var item in order.Items)
                {
                    Write(wsI, irow, iid++, oid, item.ProductId, item.Quantity, (double)item.Price);
                    irow++;
                }
                ChangeCourierOrders(wb, order.CourierId, +1);
                wb.Save();
                return oid;
            }
        }

        public static List<Order> GetOrders(string statusFilter = "")
        {
            var clients  = GetClients();
            var couriers = GetCouriers();
            var list     = new List<Order>();
            using (var wb = Open())
            {
                var ws = wb.Worksheet("Orders");
                int lr = LastRow(ws);
                for (int r = 2; r <= lr; r++)
                {
                    if (ws.Cell(r, 1).IsEmpty()) continue;
                    string st = S(ws.Cell(r, 6));
                    if (!string.IsNullOrWhiteSpace(statusFilter) &&
                        statusFilter != "Все статусы" && st != statusFilter) continue;
                    int cid = I(ws.Cell(r,2)), kid = I(ws.Cell(r,3));
                    DateTime.TryParse(S(ws.Cell(r,5)), out DateTime dt);
                    list.Add(new Order
                    {
                        Id=I(ws.Cell(r,1)), ClientId=cid, CourierId=kid,
                        DeliveryAddress=S(ws.Cell(r,4)),
                        OrderDate=dt == default ? DateTime.Now : dt,
                        Status=st, Total=D(ws.Cell(r,7)),
                        DeliveryMinutes=I(ws.Cell(r,8)),
                        ClientName  = clients .FirstOrDefault(c=>c.Id==cid)?.Name ?? "Клиент #"+cid,
                        CourierName = couriers.FirstOrDefault(c=>c.Id==kid)?.Name ?? "Курьер #"+kid
                    });
                }
            }
            return list.OrderByDescending(o => o.OrderDate).ToList();
        }

        public static void UpdateOrderStatus(int orderId, string newStatus, string oldStatus)
        {
            using (var wb = Open())
            {
                var ws  = wb.Worksheet("Orders");
                int row = FindRow(ws, orderId);
                if (row <= 1) return;
                ws.Cell(row, 6).Value = newStatus;
                if (newStatus == "Доставлен" && oldStatus != "Доставлен")
                {
                    int courierId = I(ws.Cell(row, 3));
                    ChangeCourierOrders(wb, courierId, -1);
                    IncrementMonthlyStats(wb, courierId, DateTime.Now.Year, DateTime.Now.Month);
                }
                wb.Save();
            }
        }

        // ── Monthly Stats ──────────────────────────────────────

        private static void IncrementMonthlyStats(XLWorkbook wb, int courierId, int year, int month)
        {
            var ws = wb.Worksheet("MonthlyStats");
            int lr = LastRow(ws);
            for (int r = 2; r <= lr; r++)
            {
                if (ws.Cell(r,1).IsEmpty()) continue;
                if (I(ws.Cell(r,2))==courierId && I(ws.Cell(r,3))==year && I(ws.Cell(r,4))==month)
                {
                    ws.Cell(r, 5).Value = (double)(I(ws.Cell(r,5)) + 1);
                    return;
                }
            }
            // New row
            int id  = NextId(ws);
            int row = lr + 1;
            Write(ws, row, id, courierId, year, month, 1);
        }

        public static List<CourierMonthStat> GetMonthlyStats(int year, int month)
        {
            var couriers = GetCouriers();
            var list     = new List<CourierMonthStat>();
            using (var wb = Open())
            {
                var ws = wb.Worksheet("MonthlyStats");
                int lr = LastRow(ws);
                for (int r = 2; r <= lr; r++)
                {
                    if (ws.Cell(r,1).IsEmpty()) continue;
                    if (I(ws.Cell(r,3))==year && I(ws.Cell(r,4))==month)
                    {
                        int cid = I(ws.Cell(r,2));
                        list.Add(new CourierMonthStat
                        {
                            CourierId   = cid,
                            CourierName = couriers.FirstOrDefault(c=>c.Id==cid)?.Name ?? "Курьер #"+cid,
                            Year=year, Month=month, Count=I(ws.Cell(r,5))
                        });
                    }
                }
            }
            // Add couriers with 0 if missing
            foreach (var c in couriers)
                if (!list.Any(s => s.CourierId == c.Id))
                    list.Add(new CourierMonthStat { CourierId=c.Id, CourierName=c.Name,
                        Year=year, Month=month, Count=0 });
            return list.OrderByDescending(s => s.Count).ToList();
        }

        // ── General stats ──────────────────────────────────────

        public static List<CourierStat> GetCourierStatistics()
        {
            var couriers = GetCouriers();
            var orders   = GetOrders();
            return couriers.Select(c => new CourierStat
            {
                CourierName     = c.Name,
                ActiveOrders    = c.ActiveOrders,
                TotalDeliveries = orders.Count(o => o.CourierId==c.Id && o.Status=="Доставлен")
            }).OrderByDescending(s => s.TotalDeliveries).ToList();
        }
    }
}
