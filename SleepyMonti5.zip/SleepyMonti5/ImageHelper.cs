using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace SleepyMonti
{
    public static class ImageHelper
    {
        private static readonly Dictionary<string, Image> Cache = new Dictionary<string, Image>();

        private static readonly Dictionary<string, Color> BgColors = new Dictionary<string, Color>
        {
            { "Торты",    Color.FromArgb(255, 182, 182) },
            { "Чизкейки", Color.FromArgb(255, 218, 150) },
            { "Пирожные", Color.FromArgb(182, 210, 255) },
            { "Десерты",  Color.FromArgb(170, 235, 170) },
            { "Выпечка",  Color.FromArgb(255, 238, 170) },
        };

        private static readonly Dictionary<string, string> Symbols = new Dictionary<string, string>
        {
            { "Торты",    "Т" },
            { "Чизкейки", "Ч" },
            { "Пирожные", "П" },
            { "Десерты",  "Д" },
            { "Выпечка",  "В" },
        };

        public static Image Get(string category, int size = 54)
        {
            string key = (category ?? "") + size;
            if (Cache.ContainsKey(key)) return Cache[key];

            var bmp = new Bitmap(size, size);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode     = SmoothingMode.AntiAlias;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;

                Color bg = BgColors.ContainsKey(category ?? "")
                    ? BgColors[category]
                    : Color.FromArgb(220, 220, 220);

                // Rounded background
                using (var path = RoundedRect(0, 0, size - 1, size - 1, 10))
                using (var brush = new SolidBrush(bg))
                    g.FillPath(brush, path);

                // Border
                using (var path = RoundedRect(0, 0, size - 1, size - 1, 10))
                using (var pen = new Pen(Color.FromArgb(60, 0, 0, 0), 1f))
                    g.DrawPath(pen, path);

                // Symbol
                string sym = Symbols.ContainsKey(category ?? "") ? Symbols[category] : "?";
                using (var font  = new Font("Segoe UI", size * 0.38f, FontStyle.Bold, GraphicsUnit.Pixel))
                using (var brush = new SolidBrush(Color.FromArgb(80, 50, 50)))
                {
                    var sf = new StringFormat
                    {
                        Alignment     = StringAlignment.Center,
                        LineAlignment = StringAlignment.Center
                    };
                    g.DrawString(sym, font, brush, new RectangleF(0, 0, size, size), sf);
                }
            }

            Cache[key] = bmp;
            return bmp;
        }

        private static GraphicsPath RoundedRect(float x, float y, float w, float h, float r)
        {
            var path = new GraphicsPath();
            path.AddArc(x,         y,         r * 2, r * 2, 180, 90);
            path.AddArc(x + w - r * 2, y,         r * 2, r * 2, 270, 90);
            path.AddArc(x + w - r * 2, y + h - r * 2, r * 2, r * 2,   0, 90);
            path.AddArc(x,         y + h - r * 2, r * 2, r * 2,  90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
