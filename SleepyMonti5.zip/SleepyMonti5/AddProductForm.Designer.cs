namespace SleepyMonti
{
    partial class AddProductForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelTop        = new System.Windows.Forms.Panel();
            this.lblTitle        = new System.Windows.Forms.Label();
            this.lblName         = new System.Windows.Forms.Label();
            this.txtName         = new System.Windows.Forms.TextBox();
            this.lblCategory     = new System.Windows.Forms.Label();
            this.cmbCategory     = new System.Windows.Forms.ComboBox();
            this.lblPrice        = new System.Windows.Forms.Label();
            this.nudPrice        = new System.Windows.Forms.NumericUpDown();
            this.lblDescription  = new System.Windows.Forms.Label();
            this.txtDescription  = new System.Windows.Forms.TextBox();
            this.lblAvail        = new System.Windows.Forms.Label();
            this.chkAvailable    = new System.Windows.Forms.CheckBox();
            this.btnAdd          = new System.Windows.Forms.Button();
            this.btnCancel       = new System.Windows.Forms.Button();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).BeginInit();
            this.SuspendLayout();

            // panelTop
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(88, 60, 100);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Dock      = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location  = new System.Drawing.Point(0, 0);
            this.panelTop.Name      = "panelTop";
            this.panelTop.Size      = new System.Drawing.Size(430, 48);
            this.panelTop.TabIndex  = 0;

            // lblTitle
            this.lblTitle.AutoSize  = false;
            this.lblTitle.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Font      = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Text      = "➕  Добавление нового товара";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Name      = "lblTitle";

            // lblName
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(20, 68);
            this.lblName.Name     = "lblName";
            this.lblName.Text     = "Наименование:";
            this.lblName.Font     = new System.Drawing.Font("Segoe UI", 9.5F);

            // txtName
            this.txtName.Location = new System.Drawing.Point(165, 65);
            this.txtName.Name     = "txtName";
            this.txtName.Size     = new System.Drawing.Size(245, 26);
            this.txtName.Font     = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtName.TabIndex = 1;

            // lblCategory
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(20, 108);
            this.lblCategory.Name     = "lblCategory";
            this.lblCategory.Text     = "Категория:";
            this.lblCategory.Font     = new System.Drawing.Font("Segoe UI", 9.5F);

            // cmbCategory
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDown;
            this.cmbCategory.Font          = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cmbCategory.Items.AddRange(new object[] { "Торты", "Чизкейки", "Пирожные", "Десерты", "Выпечка" });
            this.cmbCategory.Location      = new System.Drawing.Point(165, 105);
            this.cmbCategory.Name          = "cmbCategory";
            this.cmbCategory.Size          = new System.Drawing.Size(245, 26);
            this.cmbCategory.SelectedIndex = 0;
            this.cmbCategory.TabIndex      = 2;

            // lblPrice
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(20, 148);
            this.lblPrice.Name     = "lblPrice";
            this.lblPrice.Text     = "Цена (руб):";
            this.lblPrice.Font     = new System.Drawing.Font("Segoe UI", 9.5F);

            // nudPrice
            this.nudPrice.DecimalPlaces = 2;
            this.nudPrice.Increment     = new decimal(new int[] { 5, 0, 0, 0 });
            this.nudPrice.Location      = new System.Drawing.Point(165, 145);
            this.nudPrice.Maximum       = new decimal(new int[] { 10000, 0, 0, 0 });
            this.nudPrice.Minimum       = new decimal(new int[] { 1, 0, 0, 131072 });
            this.nudPrice.Name          = "nudPrice";
            this.nudPrice.Size          = new System.Drawing.Size(120, 26);
            this.nudPrice.Font          = new System.Drawing.Font("Segoe UI", 9.5F);
            this.nudPrice.TabIndex      = 3;
            this.nudPrice.Value         = new decimal(new int[] { 10, 0, 0, 0 });

            // lblDescription
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(20, 188);
            this.lblDescription.Name     = "lblDescription";
            this.lblDescription.Text     = "Описание:";
            this.lblDescription.Font     = new System.Drawing.Font("Segoe UI", 9.5F);

            // txtDescription
            this.txtDescription.Location  = new System.Drawing.Point(165, 185);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name      = "txtDescription";
            this.txtDescription.Size      = new System.Drawing.Size(245, 55);
            this.txtDescription.Font      = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDescription.TabIndex  = 4;

            // lblAvail
            this.lblAvail.AutoSize = true;
            this.lblAvail.Location = new System.Drawing.Point(20, 255);
            this.lblAvail.Name     = "lblAvail";
            this.lblAvail.Text     = "В наличии:";
            this.lblAvail.Font     = new System.Drawing.Font("Segoe UI", 9.5F);

            // chkAvailable
            this.chkAvailable.AutoSize = true;
            this.chkAvailable.Checked  = true;
            this.chkAvailable.Location = new System.Drawing.Point(165, 253);
            this.chkAvailable.Name     = "chkAvailable";
            this.chkAvailable.Text     = "Да";
            this.chkAvailable.Font     = new System.Drawing.Font("Segoe UI", 9.5F);
            this.chkAvailable.TabIndex = 5;

            // btnAdd
            this.btnAdd.BackColor  = System.Drawing.Color.FromArgb(46, 160, 67);
            this.btnAdd.FlatStyle  = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.ForeColor  = System.Drawing.Color.White;
            this.btnAdd.Font       = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Location   = new System.Drawing.Point(230, 292);
            this.btnAdd.Name       = "btnAdd";
            this.btnAdd.Size       = new System.Drawing.Size(100, 32);
            this.btnAdd.TabIndex   = 6;
            this.btnAdd.Text       = "Добавить";
            this.btnAdd.Click     += new System.EventHandler(this.btnAdd_Click);

            // btnCancel
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(180, 180, 180);
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Font      = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnCancel.Location  = new System.Drawing.Point(120, 292);
            this.btnCancel.Name      = "btnCancel";
            this.btnCancel.Size      = new System.Drawing.Size(100, 32);
            this.btnCancel.TabIndex  = 7;
            this.btnCancel.Text      = "Отмена";
            this.btnCancel.Click    += new System.EventHandler(this.btnCancel_Click);

            // AddProductForm
            this.AcceptButton    = this.btnAdd;
            this.CancelButton    = this.btnCancel;
            this.BackColor       = System.Drawing.Color.FromArgb(252, 248, 255);
            this.ClientSize      = new System.Drawing.Size(430, 344);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.cmbCategory);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.nudPrice);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.lblAvail);
            this.Controls.Add(this.chkAvailable);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnCancel);
            this.Font            = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.MinimizeBox     = false;
            this.Name            = "AddProductForm";
            this.StartPosition   = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text            = "Добавление товара";
            this.panelTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Panel          panelTop;
        private System.Windows.Forms.Label          lblTitle;
        private System.Windows.Forms.Label          lblName;
        private System.Windows.Forms.TextBox        txtName;
        private System.Windows.Forms.Label          lblCategory;
        private System.Windows.Forms.ComboBox       cmbCategory;
        private System.Windows.Forms.Label          lblPrice;
        private System.Windows.Forms.NumericUpDown  nudPrice;
        private System.Windows.Forms.Label          lblDescription;
        private System.Windows.Forms.TextBox        txtDescription;
        private System.Windows.Forms.Label          lblAvail;
        private System.Windows.Forms.CheckBox       chkAvailable;
        private System.Windows.Forms.Button         btnAdd;
        private System.Windows.Forms.Button         btnCancel;
    }
}
