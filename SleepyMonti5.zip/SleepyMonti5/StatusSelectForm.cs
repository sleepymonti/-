using System;
using System.Windows.Forms;

namespace SleepyMonti
{
    public partial class StatusSelectForm : Form
    {
        public string SelectedStatus { get; private set; }

        public StatusSelectForm(string currentStatus)
        {
            InitializeComponent();
            lblCurrentStatus.Text = currentStatus;
            cmbStatus.SelectedItem = currentStatus;
            if (cmbStatus.SelectedIndex < 0) cmbStatus.SelectedIndex = 0;
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            if (cmbStatus.SelectedItem == null)
            {
                MessageBox.Show("Выберите статус.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            SelectedStatus    = cmbStatus.SelectedItem.ToString();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
