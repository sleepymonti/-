using System;

namespace SleepyMonti
{
    public static class DeliveryHelper
    {
        private static readonly Random Rng = new Random();
        public  const int FreeThresholdMinutes = 45;

        /// <summary>Генерирует случайное время доставки от 15 до 90 минут.</summary>
        public static int GenerateMinutes() => Rng.Next(15, 91);

        public static bool IsFree(int minutes) => minutes > FreeThresholdMinutes;

        public static string FormatTime(int minutes)
        {
            if (minutes < 60)
                return minutes + " мин";
            int h = minutes / 60;
            int m = minutes % 60;
            return m == 0 ? h + " ч" : h + " ч " + m + " мин";
        }

        public static string DeliveryLabel(int minutes)
        {
            string time = FormatTime(minutes);
            return IsFree(minutes)
                ? time + "  — ДОСТАВКА БЕСПЛАТНА (> 45 мин)"
                : time;
        }
    }
}
