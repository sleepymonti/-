namespace SleepyMonti
{
    partial class StatusSelectForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelTop          = new System.Windows.Forms.Panel();
            this.lblTitle          = new System.Windows.Forms.Label();
            this.lblCurLbl         = new System.Windows.Forms.Label();
            this.lblCurrentStatus  = new System.Windows.Forms.Label();
            this.lblNewStatus      = new System.Windows.Forms.Label();
            this.cmbStatus         = new System.Windows.Forms.ComboBox();
            this.btnApply          = new System.Windows.Forms.Button();
            this.btnCancel         = new System.Windows.Forms.Button();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();

            // panelTop
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(88, 60, 100);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Dock      = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location  = new System.Drawing.Point(0, 0);
            this.panelTop.Name      = "panelTop";
            this.panelTop.Size      = new System.Drawing.Size(380, 48);
            this.panelTop.TabIndex  = 0;

            // lblTitle
            this.lblTitle.AutoSize  = false;
            this.lblTitle.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Font      = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Text      = "✏️  Изменение статуса заказа";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Name      = "lblTitle";

            // lblCurLbl
            this.lblCurLbl.AutoSize = true;
            this.lblCurLbl.Location = new System.Drawing.Point(20, 68);
            this.lblCurLbl.Name     = "lblCurLbl";
            this.lblCurLbl.Text     = "Текущий статус:";
            this.lblCurLbl.Font     = new System.Drawing.Font("Segoe UI", 9.5F);

            // lblCurrentStatus
            this.lblCurrentStatus.AutoSize  = true;
            this.lblCurrentStatus.Font      = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblCurrentStatus.ForeColor = System.Drawing.Color.FromArgb(88, 60, 100);
            this.lblCurrentStatus.Location  = new System.Drawing.Point(170, 68);
            this.lblCurrentStatus.Name      = "lblCurrentStatus";
            this.lblCurrentStatus.Text      = "";

            // lblNewStatus
            this.lblNewStatus.AutoSize = true;
            this.lblNewStatus.Location = new System.Drawing.Point(20, 108);
            this.lblNewStatus.Name     = "lblNewStatus";
            this.lblNewStatus.Text     = "Новый статус:";
            this.lblNewStatus.Font     = new System.Drawing.Font("Segoe UI", 9.5F);

            // cmbStatus
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Font          = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cmbStatus.Items.AddRange(new object[] { "В обработке", "Передан курьеру", "В пути", "Доставлен", "Отменён" });
            this.cmbStatus.Location      = new System.Drawing.Point(170, 105);
            this.cmbStatus.Name          = "cmbStatus";
            this.cmbStatus.Size          = new System.Drawing.Size(190, 26);
            this.cmbStatus.TabIndex      = 1;

            // btnApply
            this.btnApply.BackColor  = System.Drawing.Color.FromArgb(255, 140, 0);
            this.btnApply.FlatStyle  = System.Windows.Forms.FlatStyle.Flat;
            this.btnApply.ForeColor  = System.Drawing.Color.White;
            this.btnApply.Font       = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnApply.Location   = new System.Drawing.Point(255, 152);
            this.btnApply.Name       = "btnApply";
            this.btnApply.Size       = new System.Drawing.Size(105, 32);
            this.btnApply.TabIndex   = 2;
            this.btnApply.Text       = "Применить";
            this.btnApply.Click     += new System.EventHandler(this.btnApply_Click);

            // btnCancel
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(180, 180, 180);
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Font      = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnCancel.Location  = new System.Drawing.Point(145, 152);
            this.btnCancel.Name      = "btnCancel";
            this.btnCancel.Size      = new System.Drawing.Size(100, 32);
            this.btnCancel.TabIndex  = 3;
            this.btnCancel.Text      = "Отмена";
            this.btnCancel.Click    += new System.EventHandler(this.btnCancel_Click);

            // StatusSelectForm
            this.AcceptButton    = this.btnApply;
            this.CancelButton    = this.btnCancel;
            this.BackColor       = System.Drawing.Color.FromArgb(252, 248, 255);
            this.ClientSize      = new System.Drawing.Size(380, 205);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.lblCurLbl);
            this.Controls.Add(this.lblCurrentStatus);
            this.Controls.Add(this.lblNewStatus);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.btnCancel);
            this.Font            = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.MinimizeBox     = false;
            this.Name            = "StatusSelectForm";
            this.StartPosition   = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text            = "Изменение статуса";
            this.panelTop.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Panel     panelTop;
        private System.Windows.Forms.Label     lblTitle;
        private System.Windows.Forms.Label     lblCurLbl;
        private System.Windows.Forms.Label     lblCurrentStatus;
        private System.Windows.Forms.Label     lblNewStatus;
        private System.Windows.Forms.ComboBox  cmbStatus;
        private System.Windows.Forms.Button    btnApply;
        private System.Windows.Forms.Button    btnCancel;
    }
}
