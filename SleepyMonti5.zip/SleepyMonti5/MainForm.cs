using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace SleepyMonti
{
    public partial class MainForm : Form
    {
        // ── Цвета ─────────────────────────────────────────────
        private static readonly Color Primary = Color.FromArgb(88, 60, 100);
        private static readonly Color Success = Color.FromArgb(46, 160, 67);
        private static readonly Color Warning = Color.FromArgb(255, 140, 0);
        private static readonly Color Danger  = Color.FromArgb(200, 50, 50);
        private static readonly Color Info    = Color.FromArgb(70, 130, 180);
        private static readonly Color Muted   = Color.FromArgb(150, 150, 150);
        private static readonly Color Free    = Color.FromArgb(0, 160, 80);

        // ── Клиенты ───────────────────────────────────────────
        private TextBox      txtClientSearch;
        private DataGridView dgvClients;

        // ── Каталог ───────────────────────────────────────────
        private ComboBox      cmbCatFilter;
        private NumericUpDown nudMaxPrice;
        private TextBox       txtProductSearch;
        private DataGridView  dgvProducts;

        // ── Новый заказ ───────────────────────────────────────
        private TextBox      txtOrderPhone;
        private Label        lblSelectedClient;
        private ComboBox     cmbOrderCat;
        private TextBox      txtOrderSearch;
        private DataGridView dgvOrderProducts;
        private NumericUpDown nudQty;
        private Panel        pnlCartItems;       // панель с кнопками +/-
        private Label        lblTotal;

        private Label        lblAssignedCourier;
        private TextBox      txtDeliveryAddress;
        private Client       selectedClient;
        private int          currentDeliveryMinutes;
        private readonly List<OrderItem> cart = new List<OrderItem>();
        private List<Product> currentOrderProducts = new List<Product>();

        // ── Заказы ────────────────────────────────────────────
        private ComboBox     cmbOrderStatusFilter;
        private DataGridView dgvOrders;

        // ── Статистика ────────────────────────────────────────
        private DataGridView dgvStats;
        private DataGridView dgvMonthly;
        private Label        lblStatsInfo;
        private Label        lblEmployeeMonth;
        private ComboBox     cmbStatsMonth;
        private ComboBox     cmbStatsYear;

        // ═════════════════════════════════════════════════════

        public MainForm()
        {
            InitializeComponent();
            this.Load += MainForm_Load;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            RunSafe("Клиенты",     BuildClientsTab);
            RunSafe("Каталог",     BuildCatalogTab);
            RunSafe("Новый заказ", BuildNewOrderTab);
            RunSafe("Заказы",      BuildOrdersTab);
            RunSafe("Статистика",  BuildStatsTab);

            RunSafe("Загрузка клиентов",   () => LoadClients());
            RunSafe("Загрузка категорий",  LoadCategories);
            RunSafe("Загрузка товаров",    () => LoadProducts());
            RunSafe("Товары заказа",       LoadOrderProducts);
            RunSafe("Загрузка заказов",    () => LoadOrders());
            RunSafe("Загрузка статистики", LoadStats);
        }

        private static void RunSafe(string ctx, Action a)
        {
            try { a(); }
            catch (Exception ex)
            {
                MessageBox.Show("[" + ctx + "]\n" + ex.Message + "\n\n" + ex.StackTrace,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ── UI helpers ────────────────────────────────────────

        private static Button Btn(string text, Color back, int w = 130, int h = 30)
        {
            return new Button
            {
                Text = text, BackColor = back, ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Width = w, Height = h, Cursor = Cursors.Hand
            };
        }

        private static DataGridView MakeDGV(bool readOnly = true)
        {
            var dgv = new DataGridView
            {
                ReadOnly = readOnly, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White, BorderStyle = BorderStyle.None,
                RowHeadersVisible = false, EnableHeadersVisualStyles = false,
                Dock = DockStyle.Fill, RowTemplate = { Height = 28 },
                AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
                    { BackColor = Color.FromArgb(250, 245, 255) },
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Primary, ForeColor = Color.White,
                    Font = new Font("Segoe UI", 9f, FontStyle.Bold)
                }
            };
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(200, 180, 220);
            dgv.DefaultCellStyle.SelectionForeColor = Color.Black;
            return dgv;
        }

        private static Panel Bar(int h = 46)
        {
            return new Panel
            {
                Dock = DockStyle.Top, Height = h,
                BackColor = Color.FromArgb(245, 240, 252),
                Padding = new Padding(6, 7, 6, 0)
            };
        }

        // ═════════════════════════════════════════════════════
        //  ВК. КЛИЕНТЫ
        // ═════════════════════════════════════════════════════

        private void BuildClientsTab()
        {
            var bar = Bar();
            var lbl = new Label { Text = "Поиск:", AutoSize = true, Top = 9, Left = 4 };
            txtClientSearch = new TextBox { Width = 210, Top = 6, Left = 60, Height = 26 };
            txtClientSearch.KeyDown += (s, e) =>
            { if (e.KeyCode == Keys.Enter) LoadClients(txtClientSearch.Text); };

            var bSearch = Btn("Найти",       Primary, 90);  bSearch.SetBounds(278, 7, 90, 30);
            var bAdd    = Btn("Добавить",    Success, 110); bAdd.SetBounds(376, 7, 110, 30);
            var bAll    = Btn("Все клиенты", Info,    120); bAll.SetBounds(494, 7, 120, 30);

            bSearch.Click += (s, e) => LoadClients(txtClientSearch.Text);
            bAdd.Click    += BtnAddClient_Click;
            bAll.Click    += (s, e) => { txtClientSearch.Clear(); LoadClients(); };

            bar.Controls.Add(lbl); bar.Controls.Add(txtClientSearch);
            bar.Controls.Add(bSearch); bar.Controls.Add(bAdd); bar.Controls.Add(bAll);

            dgvClients = MakeDGV();
            tabClients.Controls.Add(dgvClients);
            tabClients.Controls.Add(bar);
        }

        private void LoadClients(string q = "")
        {
            if (dgvClients == null) return;
            var dt = new DataTable();
            dt.Columns.Add("ID",      typeof(int));
            dt.Columns.Add("ФИО",     typeof(string));
            dt.Columns.Add("Телефон", typeof(string));
            dt.Columns.Add("Адрес",   typeof(string));
            foreach (var c in DatabaseHelper.GetClients(q))
                dt.Rows.Add(c.Id, c.Name, c.Phone, c.Address);
            dgvClients.DataSource = dt;
            if (dgvClients.Columns.Contains("ID")) dgvClients.Columns["ID"].Width = 45;
        }

        private void BtnAddClient_Click(object sender, EventArgs e)
        {
            using (var f = new AddClientForm())
                if (f.ShowDialog() == DialogResult.OK)
                { DatabaseHelper.AddClient(f.NewClient); LoadClients();
                  MessageBox.Show("Клиент добавлен!", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        }

        // ═════════════════════════════════════════════════════
        //  ВК. КАТАЛОГ
        // ═════════════════════════════════════════════════════

        private void BuildCatalogTab()
        {
            var bar1 = Bar();
            var lCat = new Label { Text = "Категория:", AutoSize = true, Top = 9, Left = 4 };
            cmbCatFilter = new ComboBox { Width = 150, Top = 6, Left = 90, DropDownStyle = ComboBoxStyle.DropDownList };

            var lP = new Label { Text = "Макс.цена:", AutoSize = true, Top = 9, Left = 250 };
            nudMaxPrice = new NumericUpDown { Width = 90, Top = 6, Left = 330, Maximum = 99999 };

            var lS = new Label { Text = "Поиск:", AutoSize = true, Top = 9, Left = 430 };
            txtProductSearch = new TextBox { Width = 190, Top = 6, Left = 476 };

            var bFlt = Btn("Применить", Primary, 110); bFlt.SetBounds(676, 7, 110, 30);
            var bClr = Btn("Сбросить",  Muted,   100); bClr.SetBounds(794, 7, 100, 30);

            bFlt.Click += (s, e) => LoadProducts(cmbCatFilter.SelectedItem?.ToString(), nudMaxPrice.Value, txtProductSearch.Text);
            bClr.Click += (s, e) =>
            {
                if (cmbCatFilter.Items.Count > 0) cmbCatFilter.SelectedIndex = 0;
                nudMaxPrice.Value = 0; txtProductSearch.Clear(); LoadProducts();
            };

            bar1.Controls.Add(lCat); bar1.Controls.Add(cmbCatFilter);
            bar1.Controls.Add(lP);   bar1.Controls.Add(nudMaxPrice);
            bar1.Controls.Add(lS);   bar1.Controls.Add(txtProductSearch);
            bar1.Controls.Add(bFlt); bar1.Controls.Add(bClr);

            var bar2 = Bar(44);
            var bAdd = Btn("Добавить товар",   Success, 150); bAdd.SetBounds(4,   7, 150, 30);
            var bTog = Btn("Изменить наличие", Warning, 160); bTog.SetBounds(162, 7, 160, 30);
            var bDel = Btn("Удалить товар",    Danger,  140); bDel.SetBounds(330, 7, 140, 30);
            bAdd.Click += BtnAddProduct_Click;
            bTog.Click += BtnToggleAvail_Click;
            bDel.Click += BtnDeleteProduct_Click;
            bar2.Controls.Add(bAdd); bar2.Controls.Add(bTog); bar2.Controls.Add(bDel);

            dgvProducts = MakeDGV();
            dgvProducts.RowTemplate.Height = 58;

            tabCatalog.Controls.Add(dgvProducts);
            tabCatalog.Controls.Add(bar2);
            tabCatalog.Controls.Add(bar1);
        }

        private void LoadProducts(string cat = "", decimal maxPrice = 0, string search = "")
        {
            if (dgvProducts == null) return;
            var dt = new DataTable();
            dt.Columns.Add("Фото",      typeof(Image));
            dt.Columns.Add("ID",        typeof(int));
            dt.Columns.Add("Название",  typeof(string));
            dt.Columns.Add("Категория", typeof(string));
            dt.Columns.Add("Цена",      typeof(decimal));
            dt.Columns.Add("Описание",  typeof(string));
            dt.Columns.Add("Наличие",   typeof(string));
            foreach (var p in DatabaseHelper.GetProducts(cat, maxPrice, search))
                dt.Rows.Add(ImageHelper.Get(p.Category), p.Id, p.Name, p.Category,
                            p.Price, p.Description, p.IsAvailable ? "Есть" : "Нет");
            dgvProducts.DataSource = dt;
            if (dgvProducts.Columns.Contains("Фото"))
            {
                var ic = dgvProducts.Columns["Фото"] as DataGridViewImageColumn;
                if (ic != null) { ic.Width = 62; ic.ImageLayout = DataGridViewImageCellLayout.Zoom; }
            }
            if (dgvProducts.Columns.Contains("ID"))       dgvProducts.Columns["ID"].Width      = 38;
            if (dgvProducts.Columns.Contains("Цена"))     dgvProducts.Columns["Цена"].Width    = 72;
            if (dgvProducts.Columns.Contains("Наличие"))  dgvProducts.Columns["Наличие"].Width = 72;
        }

        private void LoadCategories()
        {
            var cats = DatabaseHelper.GetCategories();
            if (cmbCatFilter != null)
            {
                cmbCatFilter.DataSource = null;
                cmbCatFilter.Items.Clear();
                cmbCatFilter.DataSource = new List<string>(cats);
            }
            if (cmbOrderCat != null)
            {
                cmbOrderCat.DataSource = null;
                cmbOrderCat.Items.Clear();
                cmbOrderCat.DataSource = new List<string>(cats);
            }
        }

        private void BtnAddProduct_Click(object sender, EventArgs e)
        {
            using (var f = new AddProductForm())
                if (f.ShowDialog() == DialogResult.OK)
                { DatabaseHelper.AddProduct(f.NewProduct); LoadProducts(); LoadCategories();
                  MessageBox.Show("Товар добавлен!", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        }

        private void BtnToggleAvail_Click(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count == 0) { MessageBox.Show("Выберите товар."); return; }
            int  id    = (int)dgvProducts.SelectedRows[0].Cells["ID"].Value;
            bool avail = dgvProducts.SelectedRows[0].Cells["Наличие"].Value.ToString() == "Нет";
            DatabaseHelper.UpdateProductAvailability(id, avail);
            LoadProducts(cmbCatFilter.SelectedItem?.ToString(), nudMaxPrice.Value, txtProductSearch.Text);
        }

        private void BtnDeleteProduct_Click(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count == 0)
            { MessageBox.Show("Выберите товар.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            string name = dgvProducts.SelectedRows[0].Cells["Название"].Value.ToString();
            int    id   = (int)dgvProducts.SelectedRows[0].Cells["ID"].Value;
            if (MessageBox.Show("Удалить \"" + name + "\"?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                DatabaseHelper.DeleteProduct(id);
                LoadProducts(cmbCatFilter.SelectedItem?.ToString(), nudMaxPrice.Value, txtProductSearch.Text);
                LoadCategories(); LoadOrderProducts();
            }
        }

        // ═════════════════════════════════════════════════════
        //  ВК. НОВЫЙ ЗАКАЗ
        // ═════════════════════════════════════════════════════

        private void BuildNewOrderTab()
        {
            var tbl = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1,
                Padding = new Padding(4)
            };
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28f));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40f));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32f));

            tbl.Controls.Add(BuildClientPanel(), 0, 0);
            tbl.Controls.Add(BuildProductPanel(), 1, 0);
            tbl.Controls.Add(BuildCartPanel(), 2, 0);

            tabNewOrder.Controls.Add(tbl);
        }

        private GroupBox BuildClientPanel()
        {
            var grp = new GroupBox
            {
                Text = "1. Клиент", Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold), Padding = new Padding(6)
            };
            var lPh = new Label { Text = "Телефон:", AutoSize = true, Left = 4, Top = 22 };
            txtOrderPhone = new TextBox { Width = 150, Left = 70, Top = 18 };

            var bFind = Btn("Найти", Primary, 60, 26); bFind.SetBounds(226, 18, 60, 26);
            bFind.Click += BtnFindClient_Click;

            lblSelectedClient = new Label
            {
                Text = "Клиент не выбран", ForeColor = Muted,
                Left = 4, Top = 52, Width = 280, Height = 90, Font = new Font("Segoe UI", 9f)
            };
            var bNew = Btn("+ Новый клиент", Success, 280, 30);
            bNew.SetBounds(4, 150, 280, 30);
            bNew.Click += (s, e) =>
            {
                using (var f = new AddClientForm())
                    if (f.ShowDialog() == DialogResult.OK)
                    { f.NewClient.Id = DatabaseHelper.AddClient(f.NewClient);
                      SelectClient(f.NewClient); LoadClients(); }
            };
            grp.Controls.Add(lPh); grp.Controls.Add(txtOrderPhone);
            grp.Controls.Add(bFind); grp.Controls.Add(lblSelectedClient); grp.Controls.Add(bNew);
            return grp;
        }

        private GroupBox BuildProductPanel()
        {
            var grp = new GroupBox
            {
                Text = "2. Выбор товаров", Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold), Padding = new Padding(6)
            };
            var pnl = new Panel { Dock = DockStyle.Fill };

            var barF = new Panel { Dock = DockStyle.Top, Height = 34 };
            cmbOrderCat = new ComboBox { Width = 140, Left = 0, Top = 4, DropDownStyle = ComboBoxStyle.DropDownList };
            txtOrderSearch = new TextBox { Width = 120, Left = 148, Top = 4 };
            var bF = Btn("Найти", Primary, 60, 26); bF.SetBounds(276, 4, 60, 26);
            bF.Click += (s, e) => LoadOrderProducts();
            barF.Controls.Add(cmbOrderCat); barF.Controls.Add(txtOrderSearch); barF.Controls.Add(bF);

            dgvOrderProducts = MakeDGV();
            dgvOrderProducts.RowTemplate.Height = 58;
            dgvOrderProducts.DoubleClick += (s, e) => AddToCart();

            var barA = new Panel { Dock = DockStyle.Bottom, Height = 36 };
            var lQ = new Label { Text = "Кол-во:", AutoSize = true, Left = 4, Top = 8 };
            nudQty = new NumericUpDown { Width = 55, Left = 64, Top = 4, Minimum = 1, Maximum = 999, Value = 1 };
            var bCrt = Btn("В корзину", Primary, 120, 28); bCrt.SetBounds(126, 4, 120, 28);
            bCrt.Click += (s, e) => AddToCart();
            barA.Controls.Add(lQ); barA.Controls.Add(nudQty); barA.Controls.Add(bCrt);

            pnl.Controls.Add(dgvOrderProducts);
            pnl.Controls.Add(barA);
            pnl.Controls.Add(barF);
            grp.Controls.Add(pnl);
            return grp;
        }

        private GroupBox BuildCartPanel()
        {
            var grp = new GroupBox
            {
                Text = "3. Корзина и оформление", Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold), Padding = new Padding(6)
            };
            var pnl = new Panel { Dock = DockStyle.Fill };

            // Скроллируемая панель товаров корзины
            pnlCartItems = new Panel
            {
                Dock = DockStyle.Fill, AutoScroll = true,
                BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle
            };

            // Блок информации снизу
            var pInfo = new Panel { Dock = DockStyle.Bottom, Height = 128, Padding = new Padding(2, 4, 2, 2) };

            lblTotal = new Label
            {
                Text = "Итого: 0,00 руб.", Dock = DockStyle.Top, Height = 28,
                Font = new Font("Segoe UI", 11f, FontStyle.Bold), ForeColor = Primary
            };
            lblAssignedCourier = new Label
            {
                Text = "Курьер: назначается случайно",
                Dock = DockStyle.Top, Height = 22, ForeColor = Muted
            };
            var lAdr = new Label { Text = "Адрес доставки:", Dock = DockStyle.Top, Height = 20 };
            txtDeliveryAddress = new TextBox { Dock = DockStyle.Top, Height = 26 };

            pInfo.Controls.Add(lblTotal);
            pInfo.Controls.Add(lblAssignedCourier);
            pInfo.Controls.Add(lAdr);
            pInfo.Controls.Add(txtDeliveryAddress);

            var bPlace = Btn("ОФОРМИТЬ ЗАКАЗ", Success, 400, 38);
            bPlace.Dock = DockStyle.Bottom;
            bPlace.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            bPlace.Click += BtnPlaceOrder_Click;

            pnl.Controls.Add(pnlCartItems);
            pnl.Controls.Add(pInfo);
            pnl.Controls.Add(bPlace);
            grp.Controls.Add(pnl);
            return grp;
        }

        // ── Логика корзины ────────────────────────────────────

        private void LoadOrderProducts()
        {
            if (cmbOrderCat == null || txtOrderSearch == null || dgvOrderProducts == null) return;
            string cat    = cmbOrderCat.SelectedItem?.ToString() ?? "";
            string search = txtOrderSearch.Text.Trim();
            currentOrderProducts = DatabaseHelper.GetProducts(cat, 0, search)
                                                 .FindAll(p => p.IsAvailable);
            var dt = new DataTable();
            dt.Columns.Add("Фото",      typeof(Image));
            dt.Columns.Add("ID",        typeof(int));
            dt.Columns.Add("Товар",     typeof(string));
            dt.Columns.Add("Цена",      typeof(decimal));
            dt.Columns.Add("Категория", typeof(string));
            foreach (var p in currentOrderProducts)
                dt.Rows.Add(ImageHelper.Get(p.Category), p.Id, p.Name, p.Price, p.Category);
            dgvOrderProducts.DataSource = dt;
            if (dgvOrderProducts.Columns.Contains("Фото"))
            {
                var ic = dgvOrderProducts.Columns["Фото"] as DataGridViewImageColumn;
                if (ic != null) { ic.Width = 62; ic.ImageLayout = DataGridViewImageCellLayout.Zoom; }
            }
            if (dgvOrderProducts.Columns.Contains("ID"))   dgvOrderProducts.Columns["ID"].Width   = 35;
            if (dgvOrderProducts.Columns.Contains("Цена")) dgvOrderProducts.Columns["Цена"].Width = 70;
        }

        private void BtnFindClient_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtOrderPhone.Text))
            { MessageBox.Show("Введите телефон."); return; }
            var c = DatabaseHelper.SearchClientByPhone(txtOrderPhone.Text.Trim());
            if (c != null) SelectClient(c);
            else MessageBox.Show("Клиент не найден. Нажмите \"+ Новый клиент\".",
                "Не найден", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SelectClient(Client c)
        {
            selectedClient = c;
            lblSelectedClient.ForeColor = Success;
            lblSelectedClient.Text = "Выбран: " + c.Name + "\r\nТел: " + c.Phone +
                "\r\nАдрес: " + (string.IsNullOrWhiteSpace(c.Address) ? "—" : c.Address);
            if (!string.IsNullOrWhiteSpace(c.Address))
                txtDeliveryAddress.Text = c.Address;
        }

        private void AddToCart()
        {
            if (dgvOrderProducts.SelectedRows.Count == 0) return;
            var row = dgvOrderProducts.SelectedRows[0];
            int id  = (int)row.Cells["ID"].Value;
            var p   = currentOrderProducts.Find(x => x.Id == id);
            if (p == null) return;
            bool wasEmpty = cart.Count == 0;
            int qty = (int)nudQty.Value;
            var ex  = cart.Find(i => i.ProductId == id);
            if (ex != null) ex.Quantity += qty;
            else cart.Add(new OrderItem
            {
                ProductId=p.Id, ProductName=p.Name,
                Category=p.Category, Price=p.Price, Quantity=qty
            });
            // Время доставки генерируется один раз — при первом товаре в корзине
            if (wasEmpty && cart.Count > 0)
                currentDeliveryMinutes = DeliveryHelper.GenerateMinutes();
            RefreshCartPanel();
        }

        /// <summary>Перерисовывает панель корзины с кнопками +/− для каждого товара.</summary>
        private void RefreshCartPanel()
        {
            pnlCartItems.Controls.Clear();
            int y = 4;

            foreach (var item in cart.ToList())
            {
                var row = new Panel
                {
                    Left = 2, Top = y, Width = pnlCartItems.ClientSize.Width - 20, Height = 62,
                    BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle,
                    Tag = item
                };

                // Картинка
                var pb = new PictureBox
                {
                    Image = ImageHelper.Get(item.Category, 50),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Left = 4, Top = 4, Width = 54, Height = 54
                };

                // Название
                var lblName = new Label
                {
                    Text = item.ProductName,
                    Left = 64, Top = 4, Width = row.Width - 200, Height = 20,
                    Font = new Font("Segoe UI", 9f, FontStyle.Bold)
                };

                // Цена за шт
                var lblPrice = new Label
                {
                    Text = item.Price.ToString("N2") + " руб/шт",
                    Left = 64, Top = 24, Width = row.Width - 200, Height = 18,
                    ForeColor = Muted, Font = new Font("Segoe UI", 8.5f)
                };

                // Кнопка −
                var bMinus = new Button
                {
                    Text = "−", Left = row.Width - 134, Top = 14, Width = 28, Height = 28,
                    BackColor = Danger, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 10f, FontStyle.Bold), Cursor = Cursors.Hand, Tag = item
                };

                // Кол-во
                var lblQty = new Label
                {
                    Text = item.Quantity.ToString(),
                    Left = row.Width - 102, Top = 18, Width = 36, Height = 22,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Font = new Font("Segoe UI", 10f, FontStyle.Bold), Tag = item
                };

                // Кнопка +
                var bPlus = new Button
                {
                    Text = "+", Left = row.Width - 64, Top = 14, Width = 28, Height = 28,
                    BackColor = Success, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 10f, FontStyle.Bold), Cursor = Cursors.Hand, Tag = item
                };

                // Кнопка удалить
                var bDel = new Button
                {
                    Text = "x", Left = row.Width - 30, Top = 14, Width = 24, Height = 28,
                    BackColor = Muted, ForeColor = Color.White, FlatStyle = FlatStyle.Flat,
                    Font = new Font("Segoe UI", 9f, FontStyle.Bold), Cursor = Cursors.Hand, Tag = item
                };

                var capturedItem = item;
                bMinus.Click += (s, e) =>
                {
                    if (capturedItem.Quantity > 1) capturedItem.Quantity--;
                    else cart.Remove(capturedItem);
                    RefreshCartPanel();
                };
                bPlus.Click += (s, e) => { capturedItem.Quantity++; RefreshCartPanel(); };
                bDel.Click  += (s, e) => { cart.Remove(capturedItem); RefreshCartPanel(); };

                row.Controls.Add(pb); row.Controls.Add(lblName); row.Controls.Add(lblPrice);
                row.Controls.Add(bMinus); row.Controls.Add(lblQty); row.Controls.Add(bPlus); row.Controls.Add(bDel);

                pnlCartItems.Controls.Add(row);
                y += 68;
            }

            // Сумма (время доставки не пересчитывается при изменении кол-ва)
            if (cart.Count == 0) currentDeliveryMinutes = 0;
            decimal total = cart.Sum(i => i.Price * i.Quantity);
            bool    isFree    = cart.Count > 0 && DeliveryHelper.IsFree(currentDeliveryMinutes);
            decimal finalTotal = isFree ? 0 : total;

            if (lblTotal != null)
            {
                lblTotal.Text      = "Итого: " + finalTotal.ToString("N2") + " руб." + (isFree ? "  (БЕСПЛАТНО)" : "");
                lblTotal.ForeColor = isFree ? Free : Primary;
            }

            var courier = DatabaseHelper.AssignRandomCourier();
            if (lblAssignedCourier != null)
                lblAssignedCourier.Text = courier != null
                    ? "Курьер: " + courier.Name
                    : "Нет доступных курьеров";
        }

        private void BtnPlaceOrder_Click(object sender, EventArgs e)
        {
            if (selectedClient == null)
            { MessageBox.Show("Выберите клиента."); return; }
            if (cart.Count == 0)
            { MessageBox.Show("Корзина пуста."); return; }
            if (string.IsNullOrWhiteSpace(txtDeliveryAddress.Text))
            { MessageBox.Show("Укажите адрес доставки."); return; }

            var courier = DatabaseHelper.AssignRandomCourier();
            if (courier == null) { MessageBox.Show("Нет доступных курьеров."); return; }

            bool   isFree   = DeliveryHelper.IsFree(currentDeliveryMinutes);
            decimal rawTotal = cart.Sum(i => i.Price * i.Quantity);
            decimal finalTotal = isFree ? 0m : rawTotal;

            var order = new Order
            {
                ClientId        = selectedClient.Id,
                CourierId       = courier.Id,
                DeliveryAddress = txtDeliveryAddress.Text.Trim(),
                Total           = finalTotal,
                DeliveryMinutes = currentDeliveryMinutes,
                Items           = new List<OrderItem>(cart)
            };
            try
            {
                int id = DatabaseHelper.SaveOrder(order);
                string msg = "Заказ №" + id + " оформлен!\n" +
                             "Курьер: " + courier.Name + "\n" +
                             "Время доставки: " + DeliveryHelper.FormatTime(currentDeliveryMinutes) + "\n" +
                             (isFree ? "ДОСТАВКА БЕСПЛАТНА (>45 мин)" : "Итого: " + finalTotal.ToString("N2") + " руб.");
                MessageBox.Show(msg, "Заказ оформлен", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cart.Clear(); selectedClient = null;
                lblSelectedClient.Text = "Клиент не выбран"; lblSelectedClient.ForeColor = Muted;
                txtOrderPhone.Clear(); txtDeliveryAddress.Clear();
                RefreshCartPanel(); LoadOrders(); LoadStats();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ═════════════════════════════════════════════════════
        //  ВК. ЗАКАЗЫ
        // ═════════════════════════════════════════════════════

        private void BuildOrdersTab()
        {
            var bar = Bar();
            var lSt = new Label { Text = "Статус:", AutoSize = true, Top = 9, Left = 4 };
            cmbOrderStatusFilter = new ComboBox
            { Width=185, Top=6, Left=65, DropDownStyle=ComboBoxStyle.DropDownList };
            foreach (var s in new[]{"Все статусы","В обработке","Передан курьеру","В пути","Доставлен","Отменён"})
                cmbOrderStatusFilter.Items.Add(s);
            cmbOrderStatusFilter.SelectedIndex = 0;

            var bRef = Btn("Обновить",   Info,    100); bRef.SetBounds(260, 7, 100, 30);
            var bSt  = Btn("Изм.статус", Warning, 130); bSt.SetBounds(368, 7, 130, 30);
            bRef.Click += (s, e) => LoadOrders(cmbOrderStatusFilter.SelectedItem?.ToString());
            bSt.Click  += BtnChangeStatus_Click;

            bar.Controls.Add(lSt); bar.Controls.Add(cmbOrderStatusFilter);
            bar.Controls.Add(bRef); bar.Controls.Add(bSt);

            dgvOrders = MakeDGV();
            tabOrders.Controls.Add(dgvOrders);
            tabOrders.Controls.Add(bar);
        }

        private void LoadOrders(string filter = "")
        {
            if (dgvOrders == null) return;
            var dt = new DataTable();
            dt.Columns.Add("№",      typeof(int));
            dt.Columns.Add("Клиент", typeof(string));
            dt.Columns.Add("Курьер", typeof(string));
            dt.Columns.Add("Адрес",  typeof(string));
            dt.Columns.Add("Дата",   typeof(string));
            dt.Columns.Add("Статус", typeof(string));
            dt.Columns.Add("Сумма",  typeof(decimal));
            foreach (var o in DatabaseHelper.GetOrders(filter))
            {
                string deliveryInfo = o.DeliveryMinutes > 0
                    ? DeliveryHelper.FormatTime(o.DeliveryMinutes) + (o.IsFree ? " БЕСПЛАТНО" : "")
                    : "";
                string statusCell = string.IsNullOrEmpty(deliveryInfo)
                    ? o.Status
                    : o.Status + "  [" + deliveryInfo + "]";
                dt.Rows.Add(o.Id, o.ClientName, o.CourierName, o.DeliveryAddress,
                    o.OrderDate.ToString("dd.MM.yyyy HH:mm"),
                    statusCell, o.Total);
            }
            dgvOrders.DataSource = dt;
            if (dgvOrders.Columns.Contains("№"))      dgvOrders.Columns["№"].Width     = 40;
            if (dgvOrders.Columns.Contains("Дата"))   dgvOrders.Columns["Дата"].Width   = 112;
            if (dgvOrders.Columns.Contains("Статус")) dgvOrders.Columns["Статус"].Width = 220;
            if (dgvOrders.Columns.Contains("Сумма"))  dgvOrders.Columns["Сумма"].Width  = 75;
        }

        private void BtnChangeStatus_Click(object sender, EventArgs e)
        {
            if (dgvOrders.SelectedRows.Count == 0) { MessageBox.Show("Выберите заказ."); return; }
            int    oid   = (int)dgvOrders.SelectedRows[0].Cells["№"].Value;
            string curSt =      dgvOrders.SelectedRows[0].Cells["Статус"].Value.ToString();
            using (var f = new StatusSelectForm(curSt))
                if (f.ShowDialog() == DialogResult.OK)
                {
                    DatabaseHelper.UpdateOrderStatus(oid, f.SelectedStatus, curSt);
                    LoadOrders(cmbOrderStatusFilter.SelectedItem?.ToString());
                    LoadStats();
                }
        }

        // ═════════════════════════════════════════════════════
        //  ВК. СТАТИСТИКА
        // ═════════════════════════════════════════════════════

        private void BuildStatsTab()
        {
            // Верхняя панель кнопок
            var bar = Bar(46);
            var bRef  = Btn("Обновить",        Primary, 120); bRef.SetBounds(4,   7, 120, 30);
            var bOpen = Btn("Открыть Excel",   Info,    140); bOpen.SetBounds(132, 7, 140, 30);
            lblStatsInfo = new Label { Left = 284, Top = 10, AutoSize = true, ForeColor = Muted };

            bRef.Click  += (s, e) => LoadStats();
            bOpen.Click += (s, e) =>
            {
                try { Process.Start(new ProcessStartInfo("explorer.exe",
                    "/select,\"" + DatabaseHelper.DataFile + "\"") { UseShellExecute = true }); }
                catch { MessageBox.Show("Файл:\n" + DatabaseHelper.DataFile); }
            };
            bar.Controls.Add(bRef); bar.Controls.Add(bOpen); bar.Controls.Add(lblStatsInfo);

            // Метка работника месяца
            lblEmployeeMonth = new Label
            {
                Dock = DockStyle.Top, Height = 36, TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                BackColor = Color.FromArgb(255, 245, 180), ForeColor = Color.FromArgb(140, 90, 0)
            };

            // Фильтр месяца
            var barMonth = Bar(40);
            var lY = new Label { Text = "Год:", AutoSize = true, Top = 8, Left = 4 };
            cmbStatsYear = new ComboBox { Width = 80, Top = 4, Left = 40, DropDownStyle = ComboBoxStyle.DropDownList };
            for (int y = DateTime.Now.Year; y >= DateTime.Now.Year - 3; y--)
                cmbStatsYear.Items.Add(y);
            cmbStatsYear.SelectedIndex = 0;

            var lM = new Label { Text = "Месяц:", AutoSize = true, Top = 8, Left = 130 };
            cmbStatsMonth = new ComboBox { Width = 120, Top = 4, Left = 185, DropDownStyle = ComboBoxStyle.DropDownList };
            string[] months = { "Январь","Февраль","Март","Апрель","Май","Июнь",
                                 "Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь" };
            foreach (var m in months) cmbStatsMonth.Items.Add(m);
            cmbStatsMonth.SelectedIndex = DateTime.Now.Month - 1;

            var bMon = Btn("Показать", Primary, 100); bMon.SetBounds(316, 4, 100, 30);
            bMon.Click += (s, e) => LoadMonthlyStats();

            barMonth.Controls.Add(lY); barMonth.Controls.Add(cmbStatsYear);
            barMonth.Controls.Add(lM); barMonth.Controls.Add(cmbStatsMonth);
            barMonth.Controls.Add(bMon);

            // Общая статистика
            var lblAllTitle = new Label
            {
                Text = "Всего доставок:", Dock = DockStyle.Top, Height = 22,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold), Padding = new Padding(4, 0, 0, 0)
            };
            dgvStats = MakeDGV();

            var lblMonTitle = new Label
            {
                Text = "Статистика за месяц:", Dock = DockStyle.Top, Height = 22,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold), Padding = new Padding(4, 0, 0, 0)
            };
            dgvMonthly = MakeDGV();

            // Layout: сплитим таблицу пополам
            var split = new SplitContainer
            {
                Dock = DockStyle.Fill, Orientation = Orientation.Horizontal
            };

            split.Panel1.Controls.Add(dgvStats);
            split.Panel1.Controls.Add(lblAllTitle);
            split.Panel2.Controls.Add(dgvMonthly);
            split.Panel2.Controls.Add(lblMonTitle);

            tabStats.Controls.Add(split);
            tabStats.Controls.Add(lblEmployeeMonth);
            tabStats.Controls.Add(barMonth);
            tabStats.Controls.Add(bar);
        }

        private void LoadStats()
        {
            if (dgvStats == null) return;
            var dt = new DataTable();
            dt.Columns.Add("Курьер",              typeof(string));
            dt.Columns.Add("Всего доставок",      typeof(int));
            dt.Columns.Add("Активных заказов",    typeof(int));
            foreach (var s in DatabaseHelper.GetCourierStatistics())
                dt.Rows.Add(s.CourierName, s.TotalDeliveries, s.ActiveOrders);
            dgvStats.DataSource = dt;
            if (lblStatsInfo != null)
                lblStatsInfo.Text = "Обновлено: " + DateTime.Now.ToString("HH:mm:ss");

            LoadMonthlyStats();
        }

        private void LoadMonthlyStats()
        {
            if (dgvMonthly == null || cmbStatsYear == null || cmbStatsMonth == null) return;
            int year  = (int)cmbStatsYear.SelectedItem;
            int month = cmbStatsMonth.SelectedIndex + 1;

            var stats = DatabaseHelper.GetMonthlyStats(year, month);
            var dt    = new DataTable();
            dt.Columns.Add("Курьер",         typeof(string));
            dt.Columns.Add("Доставок за месяц", typeof(int));
            foreach (var s in stats)
                dt.Rows.Add(s.CourierName, s.Count);
            dgvMonthly.DataSource = dt;

            // Работник месяца
            var top = stats.FirstOrDefault();
            if (lblEmployeeMonth != null)
            {
                if (top != null && top.Count > 0)
                    lblEmployeeMonth.Text = "Работник месяца: " + top.CourierName +
                        " — " + top.Count + " доставок";
                else
                    lblEmployeeMonth.Text = "Работник месяца: данных пока нет";
            }
        }
    }
}
