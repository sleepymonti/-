using System;
using System.Windows.Forms;

namespace SleepyMonti
{
    public partial class AddProductForm : Form
    {
        public Product NewProduct { get; private set; }

        public AddProductForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите наименование товара.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return;
            }
            if (nudPrice.Value <= 0)
            {
                MessageBox.Show("Укажите цену больше нуля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                nudPrice.Focus();
                return;
            }
            NewProduct = new Product
            {
                Name        = txtName.Text.Trim(),
                Category    = cmbCategory.Text.Trim(),
                Price       = nudPrice.Value,
                Description = txtDescription.Text.Trim(),
                IsAvailable = chkAvailable.Checked
            };
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
