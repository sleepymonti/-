using System;
using System.Collections.Generic;

namespace SleepyMonti
{
    public class Client
    {
        public int    Id      { get; set; }
        public string Name    { get; set; }
        public string Phone   { get; set; }
        public string Address { get; set; }
    }

    public class Product
    {
        public int     Id          { get; set; }
        public string  Name        { get; set; }
        public string  Category    { get; set; }
        public decimal Price       { get; set; }
        public string  Description { get; set; }
        public bool    IsAvailable { get; set; }
    }

    public class Courier
    {
        public int    Id           { get; set; }
        public string Name         { get; set; }
        public string Phone        { get; set; }
        public int    ActiveOrders { get; set; }
    }

    public class Order
    {
        public int      Id              { get; set; }
        public int      ClientId        { get; set; }
        public string   ClientName      { get; set; }
        public int      CourierId       { get; set; }
        public string   CourierName     { get; set; }
        public string   DeliveryAddress { get; set; }
        public DateTime OrderDate       { get; set; }
        public string   Status          { get; set; }
        public decimal  Total           { get; set; }
        public int      DeliveryMinutes { get; set; }
        public bool     IsFree          => DeliveryMinutes > 45;
        public List<OrderItem> Items    { get; set; } = new List<OrderItem>();
    }

    public class OrderItem
    {
        public int     ProductId   { get; set; }
        public string  ProductName { get; set; }
        public string  Category    { get; set; }
        public int     Quantity    { get; set; }
        public decimal Price       { get; set; }
    }

    public class CourierStat
    {
        public string CourierName     { get; set; }
        public int    TotalDeliveries { get; set; }
        public int    ActiveOrders    { get; set; }
    }

    public class CourierMonthStat
    {
        public int    CourierId   { get; set; }
        public string CourierName { get; set; }
        public int    Year        { get; set; }
        public int    Month       { get; set; }
        public int    Count       { get; set; }
    }
}
