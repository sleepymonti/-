namespace SleepyMonti
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader  = new System.Windows.Forms.Panel();
            this.lblHeader    = new System.Windows.Forms.Label();
            this.tabMain      = new System.Windows.Forms.TabControl();
            this.tabClients   = new System.Windows.Forms.TabPage();
            this.tabCatalog   = new System.Windows.Forms.TabPage();
            this.tabNewOrder  = new System.Windows.Forms.TabPage();
            this.tabOrders    = new System.Windows.Forms.TabPage();
            this.tabStats     = new System.Windows.Forms.TabPage();
            this.panelHeader.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.SuspendLayout();

            // panelHeader
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(88, 60, 100);
            this.panelHeader.Controls.Add(this.lblHeader);
            this.panelHeader.Dock      = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location  = new System.Drawing.Point(0, 0);
            this.panelHeader.Name      = "panelHeader";
            this.panelHeader.Size      = new System.Drawing.Size(1260, 52);
            this.panelHeader.TabIndex  = 0;

            // lblHeader
            this.lblHeader.AutoSize  = false;
            this.lblHeader.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Font      = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblHeader.Text      = "🎂  SleepyMonti.by  —  Доставка кондитерских изделий";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHeader.Name      = "lblHeader";

            // tabMain
            this.tabMain.Controls.Add(this.tabClients);
            this.tabMain.Controls.Add(this.tabCatalog);
            this.tabMain.Controls.Add(this.tabNewOrder);
            this.tabMain.Controls.Add(this.tabOrders);
            this.tabMain.Controls.Add(this.tabStats);
            this.tabMain.Dock          = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Font          = new System.Drawing.Font("Segoe UI", 10F);
            this.tabMain.Location      = new System.Drawing.Point(0, 52);
            this.tabMain.Name          = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size          = new System.Drawing.Size(1260, 700);
            this.tabMain.TabIndex      = 1;

            // tabClients
            this.tabClients.BackColor = System.Drawing.Color.FromArgb(252, 248, 255);
            this.tabClients.Location  = new System.Drawing.Point(4, 28);
            this.tabClients.Name      = "tabClients";
            this.tabClients.Padding   = new System.Windows.Forms.Padding(6);
            this.tabClients.Size      = new System.Drawing.Size(1252, 668);
            this.tabClients.TabIndex  = 0;
            this.tabClients.Text      = "  👥 Клиенты  ";

            // tabCatalog
            this.tabCatalog.BackColor = System.Drawing.Color.FromArgb(252, 248, 255);
            this.tabCatalog.Location  = new System.Drawing.Point(4, 28);
            this.tabCatalog.Name      = "tabCatalog";
            this.tabCatalog.Padding   = new System.Windows.Forms.Padding(6);
            this.tabCatalog.Size      = new System.Drawing.Size(1252, 668);
            this.tabCatalog.TabIndex  = 1;
            this.tabCatalog.Text      = "  🎂 Каталог  ";

            // tabNewOrder
            this.tabNewOrder.BackColor = System.Drawing.Color.FromArgb(252, 248, 255);
            this.tabNewOrder.Location  = new System.Drawing.Point(4, 28);
            this.tabNewOrder.Name      = "tabNewOrder";
            this.tabNewOrder.Padding   = new System.Windows.Forms.Padding(6);
            this.tabNewOrder.Size      = new System.Drawing.Size(1252, 668);
            this.tabNewOrder.TabIndex  = 2;
            this.tabNewOrder.Text      = "  📝 Новый заказ  ";

            // tabOrders
            this.tabOrders.BackColor = System.Drawing.Color.FromArgb(252, 248, 255);
            this.tabOrders.Location  = new System.Drawing.Point(4, 28);
            this.tabOrders.Name      = "tabOrders";
            this.tabOrders.Padding   = new System.Windows.Forms.Padding(6);
            this.tabOrders.Size      = new System.Drawing.Size(1252, 668);
            this.tabOrders.TabIndex  = 3;
            this.tabOrders.Text      = "  📦 Заказы  ";

            // tabStats
            this.tabStats.BackColor = System.Drawing.Color.FromArgb(252, 248, 255);
            this.tabStats.Location  = new System.Drawing.Point(4, 28);
            this.tabStats.Name      = "tabStats";
            this.tabStats.Padding   = new System.Windows.Forms.Padding(6);
            this.tabStats.Size      = new System.Drawing.Size(1252, 668);
            this.tabStats.TabIndex  = 4;
            this.tabStats.Text      = "  📊 Статистика  ";

            // MainForm
            this.BackColor       = System.Drawing.Color.FromArgb(252, 248, 255);
            this.ClientSize      = new System.Drawing.Size(1260, 752);
            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.panelHeader);
            this.Font            = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimumSize     = new System.Drawing.Size(1060, 700);
            this.Name            = "MainForm";
            this.StartPosition   = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text            = "SleepyMonti.by — Управление доставкой кондитерских изделий";
            this.panelHeader.ResumeLayout(false);
            this.tabMain.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel      panelHeader;
        private System.Windows.Forms.Label      lblHeader;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage    tabClients;
        private System.Windows.Forms.TabPage    tabCatalog;
        private System.Windows.Forms.TabPage    tabNewOrder;
        private System.Windows.Forms.TabPage    tabOrders;
        private System.Windows.Forms.TabPage    tabStats;
    }
}
