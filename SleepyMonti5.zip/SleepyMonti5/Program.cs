using System;
using System.IO;
using System.Windows.Forms;

namespace SleepyMonti
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // Показываем все необработанные исключения с деталями
            Application.ThreadException += (s, e) =>
                MessageBox.Show("Необработанная ошибка:\n" + e.Exception.Message +
                    "\n\n" + e.Exception.StackTrace, "Критическая ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
                MessageBox.Show("Фатальная ошибка:\n" + e.ExceptionObject.ToString(),
                    "Критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            // Инициализация БД — при сбое пересоздать файл
            try
            {
                DatabaseHelper.InitializeDatabase();
            }
            catch
            {
                try
                {
                    if (File.Exists(DatabaseHelper.DataFile))
                        File.Delete(DatabaseHelper.DataFile);
                    DatabaseHelper.InitializeDatabase();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Не удалось создать базу данных:\n" + ex.Message +
                        "\n\nПуть: " + DatabaseHelper.DataFile,
                        "Ошибка запуска", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            Application.Run(new MainForm());
        }
    }
}
